#include<iostream>
#include<cmath>
#include<fstream>
#include<string>
#include<Eigen/Dense>

using namespace std;
using namespace Eigen;

int main(){
        const int N=100;
        const double pi=3.1415926535;
        const double xmin=0.0;
        const double xmax=1.0; // unit \circ{A}
        const double dx=(xmax-xmin)/(N-1); //step of x
        const double m=511.0; // electron mass, unit keV
        
        VectorXd x(N);

        for(int i=0;i<N;++i){
            x(i)=xmin+i*dx;
        }

        VectorXd V(N);

        ofstream potential("potential.csv");
        if(!potential.is_open()){
            cerr<<"Failed to open potential.csv!!"<<endl;
            return 1;
        }
        for(int i=0;i<N;++i){
            V(i)=500*(1/(2*m))*sin(pi*x(i));
            potential<<x(i)<<","<<V(i)<<endl;
        }
        potential.close();

        return 0;
}